export default {
    printWidth: 1000,
    tabWidth: 4,

    plugins: [require("prettier-plugin-tailwindcss")],
};
